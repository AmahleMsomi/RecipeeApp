﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp
{
    // Create an ingredeint class
    class Ingredient
    {
        public string Name { get; set; } //  Ingredient name
        public double Quantity { get; set; } // Ingredient Quantity
        public string Unit { get; set; } // Unit of measurement 
    }

    //class to represent steps for recipe
    class RecipeStep
    {
        public string Description { get; set; } // Description of the step
        public int Duration { get; set; } // Duration of the step
        public string DurationUnit { get; set; } // Diration of the steps

        // Method to convert duration to TimeSpan
        public TimeSpan GetTimeSpanDuration()
        {
            switch (DurationUnit.ToLower())
            {
                case "seconds":
                    return TimeSpan.FromSeconds(Duration);
                case "minutes":
                    return TimeSpan.FromMinutes(Duration);
                case "hours":
                    return TimeSpan.FromHours(Duration);
                default:
                    throw new InvalidOperationException("Invalid duration unit.");
            }
        }
    }

    // Define Recipe class to represent a recipe
    class Recipe
    {
        public string Name { get; set; } // Name of the recipe
        public Ingredient[] Ingredients { get; set; } // Array to store ingredients
        public RecipeStep[] Steps { get; set; } // Array to store recipe steps

        // Constructor to initialize a recipe with specified name, ingredients, and steps
        public Recipe(string name, Ingredient[] ingredients, RecipeStep[] steps)
        {
            Name = name;
            Ingredients = ingredients;
            Steps = steps;
        }
    }


    internal class Program
    {
        static void Main(string[] args)
        {
            // Prompt user to enter recipe details
            Console.WriteLine("Enter recipe details:");

            // Enter recipe details
            Console.Write("Recipe Name: ");
            string recipeName = Console.ReadLine();

            //Number of ingredients
            Console.Write("Number of ingredients: ");
            int numIngredients = int.Parse(Console.ReadLine());

            // Create an array to store ingredients
            Ingredient[] ingredients = new Ingredient[numIngredients];

            // Collect details for each ingredient
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"\nEnter details for ingredient {i + 1}:");
                Console.Write("Name: ");
                string name = Console.ReadLine();

                Console.Write("Quantity: ");
                double quantity = double.Parse(Console.ReadLine());

                Console.Write("Unit: ");
                string unit = Console.ReadLine();
                ingredients[i] = new Ingredient { Name = name, Quantity = quantity, Unit = unit };
            }

            // Ask for the how many steps
            Console.Write("Number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());

            //An array to store recipe steps
            RecipeStep[] steps = new RecipeStep[numSteps];

            // Collect details for each step
            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"\nEnter details for step {i + 1}:");
                Console.Write("Description: ");
                string description = Console.ReadLine();

                Console.Write("Duration: ");
                int duration = int.Parse(Console.ReadLine());

                Console.Write("Duration Unit (seconds/minutes/hours): ");
                string durationUnit = Console.ReadLine();

                steps[i] = new RecipeStep { Description = description, Duration = duration, DurationUnit = durationUnit };
            }
            // Create a Recipe object with the collected details
            Recipe recipe = new Recipe(recipeName, ingredients, steps);

            // Display the recipe details
            Console.WriteLine("\nRecipe Details:");
            Console.WriteLine($"Recipe Name: {recipe.Name}");

            Console.WriteLine("\nIngredients:");
            foreach (var ingredient in recipe.Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"Step {i + 1}: {recipe.Steps[i].Description} (Duration: {recipe.Steps[i].Duration} {recipe.Steps[i].DurationUnit})");
            }
        }
    }
}


        
    

