Description of the application. 

In the RecipeeApp , it allows the user to enter and capture any recipe ingredients and steps that they wish to store. 
It allows the user to clear any data that they have entered and change the scaling factor to their desire. 

How to run the application:
You would need a suitable IDE to run the application like Visual studio 2022 or you can use a C# online compiler like Programiz for instance. 
You will unzip the file as I�ve submitted a zipped version of the file. Once unzipped, copy the code in the �Program.cs� file and paste into any of the IDE�s I have recommended for use. 
Run the code and follow the prompts on the console. (Remember to read carefully to follow the instructions properly)
Once you are satisfied with the application, close the IDE you have chosen. 
GitHub repository:

        Credentials:
       Username: Amahlemsomi00@gmail.com
       Password: StaceyWacey5! 
       Link: https://github.com/AmahleMsomi/RecipeeApp 

Changes made for part 2:
* I�ve added all the required features for part 2
* I have fixed my exception handling. There are normally errors when the quantity and unit of measurement is entered. 
* I specified what data type is required so that the user does not get confused. 
When running the program, make sure the console window is on full size so you can see all options in the program. 
