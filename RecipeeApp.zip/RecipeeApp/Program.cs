﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeeApp
{
    // Created an ingredient class
    class Ingredient
    {
        public string Name { get; set; } // Ingredient name
        public double Quantity { get; set; } // Ingredient Quantity
        public string Unit { get; set; } // Unit of measurement
        public double Calories { get; set; } // Calories per unit
        public string FoodGroup { get; set; } // Food group

        public Ingredient(string name, double quantity, string unit, double calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;
        }
    }

    // Class to represent steps for recipe
    class RecipeStep
    {
        public string Description { get; set; } // Description of the step
    }

    // Define Recipe class to represent a recipe
    class Recipe
    {
        public string Name { get; set; } // Name of the recipe
        public List<Ingredient> Ingredients { get; set; } // List to store ingredients
        public RecipeStep[] Steps { get; set; } // Array to store number of steps in recipe

        // initialize recipe 
        public Recipe(string name, List<Ingredient> ingredients, RecipeStep[] steps)
        {
            Name = name;
            Ingredients = ingredients;
            Steps = steps;
        }

        // method to scale ingredients
        public void ScaleIngredients(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        // method to calculate total calories
        public double CalculateTotalCalories()
        {
            return Ingredients.Sum(ingredient => ingredient.Calories * ingredient.Quantity);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Recipe> recipes = new List<Recipe>();

            while (true)
            {
                // Greeting message
                Console.WriteLine("Welcome to RecipeApp!");

                // Prompt user to enter recipe details
                Console.WriteLine("Enter Recipe Details:");

                // Asks user for recipe name
                Console.Write("Recipe Name: ");
                string recipeName = Console.ReadLine();

                // Asks user for number of ingredients they are going to use
                Console.Write("Number of ingredients: ");
                int numIngredients;
                while (!int.TryParse(Console.ReadLine(), out numIngredients))
                {
                    //loop  for exception handling
                    Console.WriteLine("Invalid input. Please enter a valid integer.");
                    Console.Write("Number of ingredients: ");
                }

                // List to store ingredients
                List<Ingredient> ingredients = new List<Ingredient>();

                // Loop to collect each Ingredient
                for (int i = 0; i < numIngredients; i++)
                {
                    Console.WriteLine($"\nEnter details for ingredient {i + 1}:");
                    Console.Write("Ingredient Name: ");
                    string name = Console.ReadLine();

                    // Asks user for quntity of ingredients they are going to use
                    Console.Write("Quantity: ");
                    double quantity;
                    while (!double.TryParse(Console.ReadLine(), out quantity))
                    {
                        //loop for exception handling
                        Console.WriteLine("Invalid input. Please enter a valid number.");
                        Console.Write("Quantity: ");
                    }

                    Console.Write("Unit: ");
                    string unit = Console.ReadLine();

                    // Asks user for amount of Calories in ingredient
                    Console.Write("Calories per Unit: ");
                    double calories;
                    while (!double.TryParse(Console.ReadLine(), out calories))
                    {
                        //loop for exception handling 
                        Console.WriteLine("Invalid input. Please enter a valid number.");
                        Console.Write("Calories per Unit: ");
                    }

                    Console.Write("Food Group: ");
                    string foodGroup = Console.ReadLine();

                    ingredients.Add(new Ingredient(name, quantity, unit, calories, foodGroup));
                }

                // Prompt user on how many steps are there going to be
                Console.Write("Enter number of steps in recipe: ");
                int numSteps;
                while (!int.TryParse(Console.ReadLine(), out numSteps))
                {
                    Console.WriteLine("Invalid input. Please enter a valid integer.");
                    Console.Write("Enter number of steps in recipe: ");
                }

                // Array to store recipe steps
                RecipeStep[] steps = new RecipeStep[numSteps];

                // Loop to collect detail for each step
                for (int i = 0; i < numSteps; i++)
                {
                    Console.WriteLine($"\nEnter details for step {i + 1}: ");
                    Console.Write("Description: ");
                    string description = Console.ReadLine();

                    steps[i] = new RecipeStep { Description = description };
                }

                // Recipe object 
                Recipe recipe = new Recipe(recipeName, ingredients, steps);

                // Displaying the recipe details
                DisplayRecipe(recipe);

                // Calculate and display total calories
                double totalCalories = recipe.CalculateTotalCalories();
                Console.WriteLine($"Total Calories: {totalCalories}");

                // Check if total calories exceed 300 and notify the user
                if (totalCalories > 300)
                {
                    NotifyExceedCalories();
                }

                // Add the recipe to the list of recipes
                recipes.Add(recipe);

                Console.WriteLine("Do you want to enter another recipe? \n select (yes/no)");
                string response = Console.ReadLine();
                if (response.ToLower() != "yes")
                    break;
            }

            // Display all recipes in alphabetical order
            DisplayAllRecipes(recipes.OrderBy(recipe => recipe.Name).ToList());
        }

        // Method to display recipe details
        static void DisplayRecipe(Recipe recipe)
        {
            Console.WriteLine("************************************");
            Console.WriteLine("RECIPE DETAILS: ");
            Console.WriteLine("************************************");
            Console.WriteLine($"Recipe Name: {recipe.Name}");

            Console.WriteLine("\nINGREDIENTS:");
            foreach (var ingredient in recipe.Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }

            Console.WriteLine("\nSTEPS:");
            for (int i = 0; i < recipe.Steps.Length; i++)
            {
                Console.WriteLine($"Step {i + 1}: {recipe.Steps[i].Description}");
            }
            Console.WriteLine("*************************************************************");
        }

        // Method to display all recipes in alphabetical order
        static void DisplayAllRecipes(List<Recipe> recipes)
        {
            Console.WriteLine("\nALL RECIPES:");
            foreach (var recipe in recipes)
            {
                Console.WriteLine(recipe.Name);
            }
        }

        // Method to notify user when calories exceed 300
        static void NotifyExceedCalories()
        {
            Console.WriteLine("Warning: Total calories of the recipe exceed 300!");
        }
    }
}
